#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>

struct Configuration {
    float noRecoil;
    float aimFov;
    float aimLock;
    float aimBot;
    float aimAssist;
    int sensitivity;
    bool isAiming;
};

Configuration configuration = {0.60, 0.60, 0.60, 0.60, 0.60, 90000, false};

void toggleFeature(std::string featureFreeFire, bool isEnabled) {
    if (featureFreeFire == "isAiming") {
        configuration.isAiming = isEnabled;
    } else if (featureFreeFire == "aimBot") {
        configuration.aimBot = isEnabled && configuration.isAiming ? 1.0 : 0.0;
    }
    // Add other feature toggling logic if needed
}

int main() {
    toggleFeature("aimBot", true);
    toggleFeature("aimFov", false);

    std::ostringstream configXML;
    configXML << "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
    configXML << "<DAPT type=\"script\">\n";
    configXML << "    <!-- Other XML content -->\n";
    configXML << "    <configuration>\n";
    configXML << "        <com.dts.freefireth~[sensitivity]>\n";

    // Append configuration values
    std::vector<std::string> configLines;
    for (const auto &feature : {"noRecoil", "aimFov", "aimLock", "aimBot", "aimAssist", "sensitivity"}) {
        if (feature == "aimBot" && !configuration.isAiming) {
            configLines.push_back("<" + std::string(feature) + ">0.0</" + std::string(feature) + ">");
        } else {
            configLines.push_back("<" + std::string(feature) + ">" + std::to_string(configuration[feature]) + "</" + std::string(feature) + ">");
        }
    }
    configXML << "            " << join(configLines, "\n            ") << "\n";

    configXML << "        </com.dts.freefireth~[sensitivity]>\n";
    configXML << "    </configuration>\n";
    configXML << "</DAPT>\n";

    // Save configuration to a file
    std::ofstream configFile("config.xml");
    configFile << configXML.str();
    configFile.close();

    std::cout << "Configuration saved successfully in config.xml" << std::endl;

    return 0;
}