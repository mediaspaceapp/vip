using System;
using System.IO;
using System.Xml.Linq;
using System.Linq;

class Program
{
    static void Main()
    {
        var configuration = new
        {
            noRecoil = 0.60,
            aimFov = 0.60,
            aimLock = 0.60,
            aimBot = 0.60,
            aimAssist = 0.60,
            sensitivity = 90000,
            isAiming = false
        };

        void ToggleFeature(string featureFreeFire, bool isEnabled)
        {
            if (typeof(Program).GetProperty(featureFreeFire) != null)
            {
                typeof(Program).GetProperty(featureFreeFire).SetValue(null, isEnabled ? 1.0 : 0.0);
                if (featureFreeFire == "aimFov")
                {
                    configuration.isAiming = isEnabled;
                }
            }
        }

        // Example: Activate Aimbot and deactivate AimFov
        ToggleFeature("aimBot", true);
        ToggleFeature("aimFov", false);

        // Convert the configuration to XML
        var configXML = new XElement("DAPT",
            new XAttribute("type", "script"),
            new XElement("configuration",
                new XElement("com.dts.freefireth~[sensitivity]",
                    configuration.GetType().GetProperties()
                        .Select(feature => $"<{feature.Name}>{(feature.Name == "aimBot" && !configuration.isAiming ? 0.0 : feature.GetValue(configuration))}</{feature.Name}>")
                )
            )
        );

        // Save the configuration to an XML file
        var configPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "config.xml");
        configXML.Save(configPath);

        Console.WriteLine("Configuration saved successfully in config.xml");
    }
}