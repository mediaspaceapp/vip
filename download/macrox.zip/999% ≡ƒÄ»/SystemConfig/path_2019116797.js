// Configuración de características del juego con porcentajes
const configuration = {
    noRecoil: 0.60,
    aimFov: 0.60,
    aimLock: 0.60,
    aimBot: 0.60,
    aimAssist: 0.60,
    sensitivity: 90000,
    isAiming: false // Nueva propiedad para rastrear si la mira está subida
};

// Función para activar o desactivar una característica
function toggleFeature(featureFreeFire, isEnabled) {
    if (configuration.hasOwnProperty(featureFreeFire)) {
        // Si se activa, establece el valor en 1; de lo contrario, en 0
        configuration[featureFreeFire] = isEnabled ? 1.0 : 0.0;

        // Verifica si la característica activada es "aimFov" (mirar hacia arriba)
        if (featureFreeFire === "aimFov") {
            configuration.isAiming = isEnabled; // Actualiza el estado de la mira
        }
    }
}

// Ejemplo: Activar el Aimbot y desactivar el AimFov
toggleFeature("aimBot", true);
toggleFeature("aimFov", false);

// Convertir la configuración a formato XML
const configXML = `
<?xml version="1.0" encoding="UTF-8"?>
<DAPT type="script">
    <af>af</af>
    <co>co (in the game)</co>
    <in_the_game>com.dts.freefireth</in_the_game>
    <CURSOR_VALUE_GRAVITY>
        <CURSOR_1> 2019116681 </CURSOR_1>
        <CURSOR_2>scope.m.lib</CURSOR_2>
        <CURSOR_TYPE_CROSSHAIR>Density type no recoil</CURSOR_TYPE_CROSSHAIR>
    </CURSOR_VALUE_GRAVITY>
    <CURSOR_TYPE_CROSSHAIR>
        <CROSSHAIR>value off system</CROSSHAIR>
        <redirect>from query (in the game)</redirect>
    </CURSOR_TYPE_CROSSHAIR>
    <jexe-aimbot>dapt</jexe-aimbot>
    <configuration>
        <com.dts.freefireth~[sensitivity]>
        ${Object.keys(configuration).map(feature => {
            if (feature === "aimBot" && !configuration.isAiming) {
                return `<${feature}>0.0</${feature}>`; // Si no se está apuntando, aimBot se establece en 0.0
            }
            return `<${feature}>${configuration[feature]}</${feature}>`;
        }).join('\n')}
        </com.dts.freefireth~[sensitivity]>
    </configuration>
</DAPT>
`;

// Guardar la configuración en un archivo XML
const configFile = FileManager.local();
const configPath = configFile.joinPath(FileManager.iCloud().documentsDirectory(), "config.xml");
configFile.writeString(configPath, configXML);

console.log("Configuración guardada correctamente en config.xml");

Script.complete();