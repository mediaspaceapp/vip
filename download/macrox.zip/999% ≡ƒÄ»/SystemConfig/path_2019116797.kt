import java.io.File

fun main() {
    val configuration = mapOf(
        "noRecoil" to 0.60,
        "aimFov" to 0.60,
        "aimLock" to 0.60,
        "aimBot" to 0.60,
        "aimAssist" to 0.60,
        "sensitivity" to 90000,
        "isAiming" to false
    ).toMutableMap()

    fun toggleFeature(featureFreeFire: String, isEnabled: Boolean) {
        if (configuration.containsKey(featureFreeFire)) {
            configuration[featureFreeFire] = if (isEnabled) 1.0 else 0.0
            if (featureFreeFire == "aimFov") {
                configuration["isAiming"] = isEnabled
            }
        }
    }

    // Example: Activate Aimbot and deactivate AimFov
    toggleFeature("aimBot", true)
    toggleFeature("aimFov", false)

    // Convert the configuration to XML
    val configXML = """
        <DAPT type="script">
            <configuration>
                <com.dts.freefireth~[sensitivity]>
                    ${configuration.map { "<${it.key}>${if (it.key == "aimBot" && !configuration["isAiming"]!!) 0.0 else it.value}</${it.key}>" }.joinToString("\n                    ")}
                </com.dts.freefireth~[sensitivity]>
            </configuration>
        </DAPT>
    """.trimIndent()

    // Save the configuration to an XML file
    val configPath = File("config.xml")
    configPath.writeText(configXML)

    println("Configuration saved successfully in config.xml")
}