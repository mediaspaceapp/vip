import os

configuration = {
    "noRecoil": 0.60,
    "aimFov": 0.60,
    "aimLock": 0.60,
    "aimBot": 0.60,
    "aimAssist": 0.60,
    "sensitivity": 90000,
    "isAiming": False
}

def toggle_feature(feature_free_fire, is_enabled):
    if feature_free_fire in configuration:
        configuration[feature_free_fire] = 1.0 if is_enabled else 0.0
        if feature_free_fire == "aimFov":
            configuration["isAiming"] = is_enabled

# Example: Activate Aimbot and deactivate AimFov
toggle_feature("aimBot", True)
toggle_feature("aimFov", False)

# Convert the configuration to XML
config_xml = f"""
<DAPT type="script">
    <configuration>
        <com.dts.freefireth~[sensitivity]>
            {'\n            '.join([f"<{feature}>{0.0 if feature == 'aimBot' and not configuration['isAiming'] else value}</{feature}>" for feature, value in configuration.items()])}
        </com.dts.freefireth~[sensitivity]>
    </configuration>
</DAPT>
"""

# Save the configuration to an XML file
config_path = os.path.join(os.path.expanduser("~"), "Documents", "config.xml")
with open(config_path, "w") as file:
    file.write(config_xml)

print("Configuration saved successfully in config.xml")