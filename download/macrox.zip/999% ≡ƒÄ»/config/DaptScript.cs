using UnityEngine;

public class DaptScript : MonoBehaviour
{
    void Start()
    {
        DAPT (tipe)
        script

        *af *co (di dalam permainan)
        *di dalam permainan (com.dts.freefireth)
        [CURSOR_VALUE_GRAVITY]
        "CURSOR_1" ; 2019116797
        "CURSOR_2" ; scope.m.lib
        "CURSOR_TYPE_CROSSHAIR" ; Tipe kepadatan tanpa recoil

        [CURSOR_TYPE_CROSSHAIR]
        "CROSSHAIR" nilai sistem mati
        redirect = dari kueri (di dalam permainan)

        string redirect = "com.dts.freefireth
        completion(jexe_aimbot());

        void completion(string result)
        {

        }

        string jexe_aimbot()
        {
            
            string result = "Inilah hasil jexe_aimbot()!";
            return result;
        }
    }
}